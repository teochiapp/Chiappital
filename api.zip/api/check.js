require('dotenv').config();
const mysql = require('mysql2/promise');

async function checkAI() {
  try {
    const pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT || '3306', 10),
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME
    });
    
    const [rows] = await pool.execute(`
      SELECT symbol, price, updated_at
      FROM market_snapshot
      WHERE symbol IN ('NBIS', 'CRWV', 'AI', 'TEM', 'PLTR', 'IREN', 'ALAB')
    `);
    
    console.table(rows);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}
checkAI();
