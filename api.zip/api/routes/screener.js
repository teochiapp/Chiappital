// routes/screener.js - Rutas para obtener datos de mercado en lote (Screener)
const express = require('express');
const { getPool } = require('../database/db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// ─── Middleware de Autenticación ──────────────────────────────────────────────
router.use(authenticate);

// ─── Utilidades para Fetch ──────────────────────────────────────────────────
// En Node 18+ fetch es global. Si falla, el entorno debería actualizarse.
const TWELVE_DATA_API_KEY = '46895546a0ed453c80694154f07e3a11';

// Función auxiliar para esperar
const delay = ms => new Promise(res => setTimeout(res, ms));

async function fetchYahooBatch(symbols) {
  const query = symbols.join(',');
  const url = `https://query1.finance.yahoo.com/v8/finance/spark?symbols=${query}&interval=1d&range=1d`;
  
  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(5000),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Yahoo HTTP Error: ${response.status}`);
    }
    
    const data = await response.json();
    const results = {};
    
    if (data) {
      Object.keys(data).forEach(sym => {
        const item = data[sym];
        const closeArray = item.close;
        const price = (closeArray && closeArray.length > 0) ? closeArray[closeArray.length - 1] : null;
        const prevClose = item.chartPreviousClose || item.previousClose;
        const changePercent = (price && prevClose) ? ((price - prevClose) / prevClose) * 100 : 0;
        
        if (price !== null) {
          results[sym] = {
            price: price,
            changePercent: changePercent
          };
        }
      });
    }
    
    return Object.keys(results).length > 0 ? results : null;
  } catch (error) {
    console.error('Error en fetchYahooBatch:', error.message);
    return null;
  }
}

async function fetchTwelveDataBatch(symbols) {
  const query = symbols.join(',');
  const url = `https://api.twelvedata.com/quote?symbol=${query}&apikey=${TWELVE_DATA_API_KEY}`;
  
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) throw new Error(`TwelveData HTTP Error: ${response.status}`);
    
    const data = await response.json();
    if (data.code === 429) {
      console.warn('TwelveData Rate Limit (429)');
      return null;
    }
    
    const results = {};
    const isSingle = symbols.length === 1;
    const normalizedData = isSingle ? { [symbols[0]]: data } : data;
    
    symbols.forEach(sym => {
      const item = normalizedData[sym];
      if (item && item.close) {
        results[sym] = {
          price: parseFloat(item.close),
          changePercent: item.percent_change ? parseFloat(item.percent_change) : 0
        };
      }
    });
    
    return results;
  } catch (error) {
    console.error('Error en fetchTwelveDataBatch:', error.message);
    return null;
  }
}

async function fetchYahooCandlesForEma(symbol) {
  // Yahoo finance v8 chart para obtener histórico y calcular EMA
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=3mo`;
  
  try {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(5000),
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });
    
    if (!response.ok) throw new Error(`Yahoo Chart HTTP Error: ${response.status}`);
    
    const data = await response.json();
    if (!data.chart || !data.chart.result || data.chart.result.length === 0) {
      return null;
    }
    
    const result = data.chart.result[0];
    const quotes = result.indicators.quote[0];
    const closes = quotes.close.filter(c => c !== null && !isNaN(c));
    
    if (closes.length < 21) return null;
    
    // Cálculo manual EMA 21
    const N = 21;
    const k = 2 / (N + 1);
    
    let sum = 0;
    for (let i = 0; i < N; i++) {
      sum += closes[i];
    }
    let ema = sum / N;
    
    for (let i = N; i < closes.length; i++) {
      ema = (closes[i] * k) + (ema * (1 - k));
    }
    
    return ema;
  } catch (error) {
    console.error(`Error calculando EMA para ${symbol} en Yahoo:`, error.message);
    return null;
  }
}


// ─── GET /api/screener/quotes ────────────────────────────────────────────────
router.get('/quotes', async (req, res) => {
  try {
    const db = getPool();
    const symbolsParam = req.query.symbols;
    
    if (!symbolsParam) {
      return res.status(400).json({ error: { message: 'Se requiere el parámetro symbols' } });
    }
    
    const symbols = symbolsParam.split(',').map(s => s.trim().toUpperCase());
    if (symbols.length === 0) return res.json({ data: {} });
    
    const now = new Date();
    // Cache de 30 minutos
    const expirationTime = new Date(now.getTime() - 30 * 60 * 1000);
    
    // 1. Obtener desde MySQL market_cache
    const placeholders = symbols.map(() => '?').join(',');
    const [cachedRows] = await db.query(
      `SELECT symbol, price, change_pct, price_at, source FROM market_cache WHERE symbol IN (${placeholders})`,
      symbols
    );
    
    const resultQuotes = {};
    const missingSymbols = [];
    
    cachedRows.forEach(row => {
      if (row.price_at && new Date(row.price_at) > expirationTime) {
        // Cache fresco
        resultQuotes[row.symbol] = {
          price: parseFloat(row.price),
          changePercent: parseFloat(row.change_pct),
          source: row.source || 'cache',
          stale: false
        };
      } else {
        // Expirado
        missingSymbols.push(row.symbol);
        // Lo guardamos igual por si fallan las APIs tener un dato staled
        resultQuotes[row.symbol] = {
          price: parseFloat(row.price),
          changePercent: parseFloat(row.change_pct),
          source: row.source || 'cache',
          stale: true
        };
      }
    });
    
    // Los que no están en la DB también son missing
    symbols.forEach(sym => {
      if (!resultQuotes[sym] && !missingSymbols.includes(sym)) {
        missingSymbols.push(sym);
      }
    });
    
    // 2. Fetch de missingSymbols en batches
    if (missingSymbols.length > 0) {
      const batchSize = 100; // Yahoo permite hasta 200, usamos 100 para estar seguros
      
      for (let i = 0; i < missingSymbols.length; i += batchSize) {
        const batch = missingSymbols.slice(i, i + batchSize);
        console.log(`[Screener] Fetching batch de ${batch.length} símbolos a Yahoo...`);
        
        let batchResults = await fetchYahooBatch(batch);
        let usedSource = 'yahoo';
        
        // Si Yahoo falla totalmente, fallback a TwelveData
        if (!batchResults) {
          console.log(`[Screener] Yahoo falló para el batch, usando fallback TwelveData...`);
          // Twelve data es mejor limitarlo a 30 por URL
          const tdBatch = batch.slice(0, 30);
          batchResults = await fetchTwelveDataBatch(tdBatch);
          usedSource = 'twelvedata';
          
          // Agregamos un delay de 8s si usamos twelvedata para respetar su rate limit si hay más batches
          if (i + batchSize < missingSymbols.length) {
            await delay(8000);
          }
        }
        
        if (batchResults) {
          // Actualizamos los resultados y guardamos en BD
          for (const sym of batch) {
            const data = batchResults[sym];
            if (data && data.price) {
              resultQuotes[sym] = {
                price: data.price,
                changePercent: data.changePercent,
                source: usedSource,
                stale: false
              };
              
              // Guardar/Actualizar en DB
              await db.query(`
                INSERT INTO market_cache (symbol, price, change_pct, price_at, source)
                VALUES (?, ?, ?, NOW(), ?)
                ON DUPLICATE KEY UPDATE 
                  price = VALUES(price), 
                  change_pct = VALUES(change_pct), 
                  price_at = NOW(), 
                  source = VALUES(source)
              `, [sym, data.price, data.changePercent, usedSource]);
            } else if (resultQuotes[sym] && resultQuotes[sym].price) {
              // Si no lo encontramos en la API, pero tenemos un precio stale, conservarlo stale
              // y no hacer update en DB.
            } else {
              // No hay precio en API ni en DB
              resultQuotes[sym] = { price: null, changePercent: null, stale: true };
            }
          }
        }
      }
    }
    
    res.json({ data: resultQuotes });
  } catch (error) {
    console.error('Error en /api/screener/quotes:', error);
    res.status(500).json({ error: { message: 'Error interno del servidor al obtener cotizaciones.' } });
  }
});


// ─── GET /api/screener/ema ───────────────────────────────────────────────────
router.get('/ema', async (req, res) => {
  try {
    const db = getPool();
    const symbol = req.query.symbol;
    const currentPriceStr = req.query.price;
    
    if (!symbol || !currentPriceStr) {
      return res.status(400).json({ error: { message: 'Se requieren los parámetros symbol y price' } });
    }
    
    const currentPrice = parseFloat(currentPriceStr);
    const safeSymbol = symbol.trim().toUpperCase();
    
    const now = new Date();
    // Cache de EMA21 de 24 horas
    const expirationTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    
    // 1. Obtener de DB
    const [rows] = await db.query(
      `SELECT ema21, ema21_at FROM market_cache WHERE symbol = ?`,
      [safeSymbol]
    );
    
    let ema = null;
    let cached = false;
    
    if (rows.length > 0 && rows[0].ema21_at && new Date(rows[0].ema21_at) > expirationTime) {
      ema = parseFloat(rows[0].ema21);
      cached = true;
    }
    
    // 2. Si no hay cache fresco, calcular bajando de Yahoo
    if (!cached) {
      console.log(`[Screener] Calculando EMA21 para ${safeSymbol} desde Yahoo...`);
      ema = await fetchYahooCandlesForEma(safeSymbol);
      
      if (ema) {
        // Guardar en DB
        await db.query(`
          INSERT INTO market_cache (symbol, ema21, ema21_at)
          VALUES (?, ?, NOW())
          ON DUPLICATE KEY UPDATE 
            ema21 = VALUES(ema21), 
            ema21_at = NOW()
        `, [safeSymbol, ema]);
      } else if (rows.length > 0 && rows[0].ema21) {
        // Si falló calcular pero hay stale cache, usarlo
        ema = parseFloat(rows[0].ema21);
      }
    }
    
    if (ema === null) {
      return res.json({ data: { symbol: safeSymbol, ema21: null, distancePercent: null } });
    }
    
    const distancePercent = ((currentPrice - ema) / ema) * 100;
    
    res.json({ 
      data: { 
        symbol: safeSymbol, 
        ema21: ema, 
        distancePercent: distancePercent,
        cached: cached
      } 
    });
    
  } catch (error) {
    console.error('Error en /api/screener/ema:', error);
    res.status(500).json({ error: { message: 'Error interno al calcular EMA.' } });
  }
});

module.exports = router;
